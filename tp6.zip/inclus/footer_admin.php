<div class="footer-copyright">
    <p><b>© 2022 - Tous droits réservé</b></p>
    <p><b><a href="index.php" id="connection">deconnection </a></b></p>
</div>
</div>

</body>

</html>