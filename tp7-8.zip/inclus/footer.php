<div class="footer-copyright">
    <p><b>© 2022 - Tous droits réservé</b></p>
    <p><b><a href="connection.php" id="connection">Connexion </a></b></p>
</div>
</div>


</body>

</html>