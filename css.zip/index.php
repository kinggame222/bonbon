<?php
include 'inclus/header.php'
?>
<?php
require "librairies/fonction.php";
$bd;
connecterBD($bd);    // appel de la fonction dans fonction.php

?>
<div id="texte">
    <p>Bonjour,</p>
    <p>Pour faire plaisir a mes enfant et aux amis de mes enfant , j'ai ouvert cette boutique de bonbon en 2010
        et depuis, elle n'a cessé de prendre de l'expension.Aujourd'hui, avec la venu du Web, je suis ,heureux
        de vous présenter la nouvelle facons de magasiner des bonbons ...</p>
    <p align="center">Bon magasinage !</p>
</div>

<?php
include 'inclus/footer.php'
?>