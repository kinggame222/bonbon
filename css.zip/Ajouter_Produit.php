<?php
include 'inclus/header_admin.php'
?>

<div id="texte">


    <div class="row">

        <div class="col-3">
            <label for="">Nom du produit:</label>
        </div>
        <div class="col-9">
            <input type="text">
        </div>
        <label for="">Prix:</label>
        <label for="">Fournisseur:</label>
        <label for="">quantité:</label>
        <label for="">format:</label>
        <label for="">remarque:</label>



    </div>

</div>





<?php
include 'inclus/footer_admin.php'
?>